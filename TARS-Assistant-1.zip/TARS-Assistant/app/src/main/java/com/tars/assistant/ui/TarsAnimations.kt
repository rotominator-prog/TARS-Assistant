package com.tars.assistant.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.unit.dp
import com.tars.assistant.ui.theme.TarsColors
import kotlin.math.*
import kotlin.random.Random

// ── 1. TARS MONOLITH — pulsează și reacționează ──────────────
@Composable
fun TarsMonolith(
    modifier: Modifier = Modifier,
    isThinking: Boolean = false,
    isSpeaking: Boolean = false,
    isListening: Boolean = false,
    humorLevel: Int = 75
) {
    val infiniteTransition = rememberInfiniteTransition(label = "monolith")

    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(if (isThinking) 400 else if (isSpeaking) 600 else 2000, easing = EaseInOutSine),
            RepeatMode.Reverse
        ), label = "glow"
    )

    val scanLine by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2500, easing = LinearEasing)),
        label = "scan"
    )

    val rotationY by infiniteTransition.animateFloat(
        initialValue = -8f, targetValue = 8f,
        animationSpec = infiniteRepeatable(tween(4000, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "rotate"
    )

    val accentColor = when {
        isListening -> TarsColors.StatusError
        isSpeaking  -> TarsColors.AccentCyan
        isThinking  -> TarsColors.StatusWarn
        else        -> TarsColors.AccentCyan
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f

        // Perspective skew based on rotationY
        val skew = rotationY / 90f * 0.15f

        // ── Outer glow halo ──
        drawCircle(
            brush = Brush.radialGradient(
                listOf(accentColor.copy(alpha = glowPulse * 0.15f), Color.Transparent),
                center = Offset(cx, cy),
                radius = w * 0.9f
            ),
            radius = w * 0.9f,
            center = Offset(cx, cy)
        )

        // ── Monolith body with perspective ──
        val mw = w * 0.38f
        val mh = h * 0.82f
        val left  = cx - mw / 2 + skew * h
        val right = cx + mw / 2 + skew * h
        val top   = cy - mh / 2f
        val bottom = cy + mh / 2f

        val path = Path().apply {
            moveTo(left, top)
            lineTo(right, top)
            lineTo(right, bottom)
            lineTo(left, bottom)
            close()
        }

        // Body fill gradient
        drawPath(
            path,
            brush = Brush.verticalGradient(
                listOf(
                    TarsColors.SurfaceVariant.copy(0.9f),
                    TarsColors.Surface.copy(0.6f),
                    TarsColors.Background.copy(0.8f)
                ),
                startY = top, endY = bottom
            )
        )

        // Body border glow
        drawPath(
            path,
            color = accentColor.copy(alpha = glowPulse * 0.9f),
            style = Stroke(width = 1.5.dp.toPx())
        )

        // ── Scanline sweep ──
        val scanY = top + (bottom - top) * scanLine
        drawLine(
            brush = Brush.horizontalGradient(
                listOf(Color.Transparent, accentColor.copy(0.6f), Color.Transparent),
                startX = left, endX = right
            ),
            start = Offset(left, scanY),
            end = Offset(right, scanY),
            strokeWidth = 1.dp.toPx()
        )

        // ── Interior segments (the "lights") ──
        val segCount = 5
        val segH = mh * 0.06f
        val segW = mw * 0.55f
        val segSpacing = mh / (segCount + 1)

        repeat(segCount) { i ->
            val segAlpha = when {
                isThinking -> if (i % 2 == 0) glowPulse else 1f - glowPulse
                isSpeaking -> abs(sin((i * 0.8f + glowPulse * 3f)))
                else       -> 0.25f + (i.toFloat() / segCount) * 0.3f
            }
            val sy = top + segSpacing * (i + 1)
            drawRoundRect(
                color = accentColor.copy(alpha = segAlpha * 0.8f),
                topLeft = Offset(cx - segW / 2, sy - segH / 2),
                size = androidx.compose.ui.geometry.Size(segW, segH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
            )
        }

        // ── Corner brackets ──
        val bSize = 8.dp.toPx()
        val bStroke = 1.5.dp.toPx()
        val corners = listOf(
            Pair(left, top) to Pair(1f, 1f),
            Pair(right, top) to Pair(-1f, 1f),
            Pair(left, bottom) to Pair(1f, -1f),
            Pair(right, bottom) to Pair(-1f, -1f)
        )
        corners.forEach { (pos, dir) ->
            drawLine(accentColor.copy(glowPulse * 0.8f),
                Offset(pos.first, pos.second),
                Offset(pos.first + dir.first * bSize, pos.second),
                strokeWidth = bStroke)
            drawLine(accentColor.copy(glowPulse * 0.8f),
                Offset(pos.first, pos.second),
                Offset(pos.first, pos.second + dir.second * bSize),
                strokeWidth = bStroke)
        }

        // ── Humor level indicator bar (bottom) ──
        val barW = mw * 0.7f
        val barH = 3.dp.toPx()
        val barY = bottom - 14.dp.toPx()
        val barX = cx - barW / 2
        drawRoundRect(
            color = TarsColors.Border,
            topLeft = Offset(barX, barY),
            size = androidx.compose.ui.geometry.Size(barW, barH),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
        )
        drawRoundRect(
            brush = Brush.horizontalGradient(
                listOf(TarsColors.AccentCyanDim, accentColor),
                startX = barX, endX = barX + barW
            ),
            topLeft = Offset(barX, barY),
            size = androidx.compose.ui.geometry.Size(barW * (humorLevel / 100f), barH),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
        )
    }
}

// ── 2. STARFIELD — fundal Interstellar ───────────────────────
data class Star(val x: Float, val y: Float, val size: Float, val speed: Float, val alpha: Float)

@Composable
fun StarfieldBackground(modifier: Modifier = Modifier) {
    val stars = remember {
        List(120) {
            Star(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                size = Random.nextFloat() * 2.5f + 0.3f,
                speed = Random.nextFloat() * 0.0003f + 0.0001f,
                alpha = Random.nextFloat() * 0.7f + 0.2f
            )
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "stars")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(60000, easing = LinearEasing)),
        label = "time"
    )

    Canvas(modifier = modifier) {
        stars.forEach { star ->
            val x = (star.x + time * star.speed * 10f) % 1f
            val y = star.y
            val twinkle = (sin(time * 20f * star.speed * 100f + star.x * 10f) * 0.3f + 0.7f).toFloat()
            drawCircle(
                color = TarsColors.TextPrimary.copy(alpha = star.alpha * twinkle),
                radius = star.size.dp.toPx() / 2f,
                center = Offset(x * size.width, y * size.height)
            )
        }
    }
}

// ── 3. BOOT SEQUENCE ─────────────────────────────────────────
@Composable
fun BootSequence(onComplete: () -> Unit) {
    var phase by remember { mutableStateOf(0) }
    var displayedLines by remember { mutableStateOf(listOf<String>()) }

    val bootLines = listOf(
        "TARS SYSTEM v1.0.0",
        "© NASA / COOPER STATION",
        "────────────────────────",
        "Inițializare nucleu AI..........  [OK]",
        "Calibrare umor: 75%..............  [OK]",
        "Conectare Claude API.............  [OK]",
        "Încărcare module vocale..........  [OK]",
        "Verificare integritate date......  [OK]",
        "Protocoale etice active..........  [OK]",
        "────────────────────────",
        "TARS OPERAȚIONAL.",
        "Onestitate: 90% // Umor: 75%"
    )

    LaunchedEffect(Unit) {
        for (line in bootLines) {
            kotlinx.coroutines.delay(180)
            displayedLines = displayedLines + line
        }
        kotlinx.coroutines.delay(800)
        onComplete()
    }

    val infiniteTransition = rememberInfiniteTransition(label = "cursor")
    val cursorVisible by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(500), RepeatMode.Reverse),
        label = "blink"
    )

    androidx.compose.foundation.layout.Box(
        modifier = Modifier
            .fillMaxSize()
            .androidx.compose.foundation.background(TarsColors.Background)
    ) {
        StarfieldBackground(Modifier.fillMaxSize())

        androidx.compose.foundation.layout.Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
        ) {
            displayedLines.forEachIndexed { idx, line ->
                androidx.compose.animation.AnimatedVisibility(
                    visible = true,
                    enter = fadeIn(tween(200)) + expandVertically()
                ) {
                    androidx.compose.material3.Text(
                        text = if (idx == displayedLines.lastIndex) "$line▌".take(
                            if (cursorVisible > 0.5f) line.length + 1 else line.length
                        ) else line,
                        style = androidx.compose.material3.MaterialTheme.typography.bodyMedium,
                        color = when {
                            line.startsWith("TARS SYSTEM") -> TarsColors.AccentCyan
                            line.startsWith("TARS OPER") -> TarsColors.StatusGreen
                            line.contains("[OK]") -> TarsColors.TextPrimary
                            line.startsWith("──") -> TarsColors.Border
                            else -> TarsColors.TextSecondary
                        }
                    )
                }
            }
        }
    }
}

// ── 4. GLITCH EFFECT TEXT ────────────────────────────────────
@Composable
fun GlitchText(
    text: String,
    modifier: Modifier = Modifier,
    active: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "glitch")
    val glitchOffset by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = if (active) 4f else 0f,
        animationSpec = if (active) infiniteRepeatable(tween(80), RepeatMode.Reverse)
        else snap(),
        label = "glitch"
    )

    androidx.compose.foundation.layout.Box(modifier = modifier) {
        if (active) {
            // Red channel offset
            androidx.compose.material3.Text(
                text,
                color = TarsColors.StatusError.copy(0.5f),
                modifier = Modifier.offset(x = glitchOffset.dp, y = 0.dp),
                style = androidx.compose.material3.MaterialTheme.typography.headlineMedium
            )
            // Blue channel offset
            androidx.compose.material3.Text(
                text,
                color = TarsColors.AccentCyan.copy(0.5f),
                modifier = Modifier.offset(x = (-glitchOffset).dp, y = 0.dp),
                style = androidx.compose.material3.MaterialTheme.typography.headlineMedium
            )
        }
        // Main text
        androidx.compose.material3.Text(
            text,
            color = TarsColors.AccentCyan,
            style = androidx.compose.material3.MaterialTheme.typography.headlineMedium
        )
    }
}

// ── 5. LIVE WAVEFORM pentru microfon ─────────────────────────
@Composable
fun LiveWaveform(
    modifier: Modifier = Modifier,
    isActive: Boolean = false,
    color: Color = TarsColors.AccentCyan,
    barCount: Int = 24
) {
    val infiniteTransition = rememberInfiniteTransition(label = "livewave")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "wavetime"
    )

    Canvas(modifier = modifier) {
        if (!isActive) return@Canvas
        val barW = (size.width / barCount) * 0.6f
        val gap  = (size.width / barCount) * 0.4f
        repeat(barCount) { i ->
            val phase = i.toFloat() / barCount * 2f * PI.toFloat()
            val height = (abs(sin(time + phase)) * 0.7f + abs(sin(time * 1.7f + phase * 0.5f)) * 0.3f)
            val barH = height * size.height
            val x = i * (barW + gap) + gap / 2
            val y = (size.height - barH) / 2f
            drawRoundRect(
                color = color.copy(alpha = 0.5f + height * 0.5f),
                topLeft = Offset(x, y),
                size = androidx.compose.ui.geometry.Size(barW, barH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx())
            )
        }
    }
}

// ── 6. HEX GRID BACKGROUND ───────────────────────────────────
@Composable
fun HexGridBackground(modifier: Modifier = Modifier, alpha: Float = 0.06f) {
    Canvas(modifier = modifier) {
        val hexSize = 28.dp.toPx()
        val hexH = hexSize * sqrt(3f)
        var row = 0
        var y = 0f
        while (y < size.height + hexH) {
            var x = if (row % 2 == 0) 0f else hexSize * 1.5f
            while (x < size.width + hexSize * 3) {
                val path = Path()
                for (i in 0..5) {
                    val angle = (PI / 3 * i - PI / 6).toFloat()
                    val px = x + hexSize * cos(angle)
                    val py = y + hexSize * sin(angle)
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                drawPath(path, color = TarsColors.Border.copy(alpha), style = Stroke(0.5.dp.toPx()))
                x += hexSize * 3
            }
            y += hexH / 2
            row++
        }
    }
}
